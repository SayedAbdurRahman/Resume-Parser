from ..fil_PH import Provider as FilPhProvider


class Provider(FilPhProvider):
    """No difference from Company Provider for fil_PH locale"""

    pass
